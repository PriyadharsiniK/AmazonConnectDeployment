import {DynamoDBClient, ScanCommand} from "@aws-sdk/client-dynamodb";
import {DynamoDBDocumentClient} from "@aws-sdk/lib-dynamodb";

const dynamodb=DynamoDBDocumentClient.from(new DynamoDBClient({region: "us-west-2"}));

export const handler = async (event) => {
console.log("Received event:", JSON.stringify(event, null, 2));

  const params={
    TableName: "LoyaltyMembers",
    FilterExpression: "#mobileNo=:mobileValue",
    ExpressionAttributeNames:{
      "#mobileNo":"MobileNo"
    },
    ExpressionAttributeValues:{
      ":mobileValue": {S:event.Details.ContactData.CustomerEndpoint.Address},
    },
  };
  try{
    console.log("Scanning DynamoDB table for member with mobile number:", event.Details.ContactData.CustomerEndpoint.Address);
    const data=await dynamodb.send(new ScanCommand(params));
    console.log("Scan result:", JSON.stringify(data, null, 2));
    if(!data.Items||data.Items.length===0){
      console.log("No member found with the given mobile number");
      return {
        statusCode: 404,
        body: JSON.stringify({ message: "No member found with the given mobile number" }),
      };
    }
    const response = {
      statusCode: 200,
      body: JSON.stringify('Member found with the given mobile number'),
      data: data.Items[0].Name
    };
    return response;
  }
  catch(error){
    console.log(error);
    return {
      statusCode: 500,
      body: JSON.stringify({ message: "Internal Server Error", error: error.message }),
    };
  }

};
