import {DynamoDBClient} from "@aws-sdk/client-dynamodb";
import {DynamoDBDocumentClient,GetCommand} from "@aws-sdk/lib-dynamodb";

const client=new DynamoDBClient({region: "us-west-2"});
const dynamodb= DynamoDBDocumentClient.from(client);

export const handler = async (event) => {
  console.log("Event received:",event);
  if(!event.OrderNo){
    return {
      statusCode: 400,
      body: "Order Number is required"
    }
  };
  const params={
    TableName: "OrderDetails",
    Key: {
      OrderNo: event.OrderNo
    }
  };
  try
  {
  const data= await dynamodb.send(new GetCommand(params));
  console.log(data);
  if(!data.Item){
    console.log("Order not found");
    return {
      statusCode: 404,
      body: JSON.stringify('Order not found'),
    };
  }
  const response = {
    statusCode: 200,
    body: JSON.stringify('Hello from Lambda!'),
    data: data.Item.Status
  };
  return response;
}
catch (error)
{
  console.error(error);
  return {
    statusCode: 500,
    body: JSON.stringify('Error retrieving data from DynamoDB'),
  };
  }
};
